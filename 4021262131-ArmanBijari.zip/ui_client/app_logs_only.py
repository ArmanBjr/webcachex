import sys

from PyQt5.QtWidgets import QApplication, QMainWindow

from ui_client.utils.csv_loader import load_cache_log, load_origin_log
from ui_client.widgets.log_viewer_widget import LogViewerWidget


def build_rows():
    rows = []
    rows += load_cache_log("E:/University/University_Subjects/5th/Computer_Networks/Projects/project/cache_server/cache_log.csv")
    rows += load_origin_log("E:/University/University_Subjects/5th/Computer_Networks/Projects/project/web_server/origin_a_log.csv", component="originA")
    rows += load_origin_log("E:/University/University_Subjects/5th/Computer_Networks/Projects/project/web_server/origin_b_log.csv", component="originB")
    return rows


if __name__ == "__main__":
    app = QApplication(sys.argv)

    w = LogViewerWidget(loader_fn=build_rows)
    w.reload_logs() 
    w.show()



    win = QMainWindow()
    win.setWindowTitle("WebCacheX — Logs (Stage 3)")
    win.setCentralWidget(w)
    win.resize(1200, 650)
    win.show()

    sys.exit(app.exec_())
