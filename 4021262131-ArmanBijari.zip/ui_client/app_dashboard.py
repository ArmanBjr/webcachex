import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QTabWidget

from utils.csv_loader import load_cache_log, load_origin_log
from widgets.log_viewer_widget import LogViewerWidget
from tabs.client_tab import ClientTab

CACHE_LOG = r"E:/University/University_Subjects/5th/Computer_Networks/Projects/project/cache_server/cache_log.csv"
ORIGIN_A_LOG = r"E:/University/University_Subjects/5th/Computer_Networks/Projects/project/web_server/origin_a_log.csv"
ORIGIN_B_LOG = r"E:/University/University_Subjects/5th/Computer_Networks/Projects/project/web_server/origin_b_log.csv"


def load_cache_rows():
    return load_cache_log(CACHE_LOG)


def load_origin_a_rows():
    return load_origin_log(ORIGIN_A_LOG, component="originA")


def load_origin_b_rows():
    return load_origin_log(ORIGIN_B_LOG, component="originB")


def main():
    app = QApplication(sys.argv)

    tabs = QTabWidget()

    # Tab 1: Client
    tabs.addTab(ClientTab(cache_host="127.0.0.1", cache_port=8080), "Client")

    # Tab 2: Cache Logs
    w_cache = LogViewerWidget(loader_fn=load_cache_rows)
    w_cache.reload_logs()
    tabs.addTab(w_cache, "Cache Logs")

    # Tab 3: Origin A Logs
    w_a = LogViewerWidget(loader_fn=load_origin_a_rows)
    w_a.reload_logs()
    tabs.addTab(w_a, "Origin A Logs")

    # Tab 4: Origin B Logs
    w_b = LogViewerWidget(loader_fn=load_origin_b_rows)
    w_b.reload_logs()
    tabs.addTab(w_b, "Origin B Logs")

    win = QMainWindow()
    win.setWindowTitle("WebCacheX — Dashboard")
    win.setCentralWidget(tabs)
    win.resize(1350, 750)
    win.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
