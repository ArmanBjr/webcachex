from utils.csv_loader import load_cache_log, load_origin_log

cache = load_cache_log("E:/University/University_Subjects/5th/Computer_Networks/Projects/project/cache_server/cache_log.csv")
a = load_origin_log("E:/University/University_Subjects/5th/Computer_Networks/Projects/project/web_server/origin_a_log.csv", component="originA")
b = load_origin_log("E:/University/University_Subjects/5th/Computer_Networks/Projects/project/web_server/origin_b_log.csv", component="originB")

print("cache rows:", len(cache))
print("A rows:", len(a))
print("B rows:", len(b))

print("sample cache row:", cache[-1] if cache else None)
print("sample originA row:", a[-1] if a else None)
